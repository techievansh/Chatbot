﻿using ChatBotUsingSignalR.Models;
using Microsoft.AspNet.SignalR.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System.Security.Claims;

namespace ChatBotUsingSignalR.Hubs
{
    public class ChatHub:Hub
    {
        private readonly AppDbContext _context;
        private static Dictionary<string, string> ConnectedUsers = new Dictionary<string, string>();
        public ChatHub(AppDbContext context)
        {
            _context = context;
        }
        public override async Task OnConnectedAsync()
        {
            var userId = Context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrEmpty(userId))
            {
                ConnectedUsers[userId] = Context.ConnectionId;
            }
                    
            await base.OnConnectedAsync();            
        }
        public override async Task OnDisconnectedAsync(Exception exception)
        {
            var userId = Context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrEmpty(userId)) {
                ConnectedUsers.Remove(userId, out _);
            }
            
            await base.OnDisconnectedAsync(exception);
        }
        public async Task SendMessage(int user, string message,int LoginId)
        {
            ChatMgt chatMgt = new ChatMgt();
            chatMgt.ReceiverId = user;
            chatMgt.Chat = message;
            chatMgt.SenderId = LoginId;
            var getUserDetail = _context.ChatMgt.Add(chatMgt);
            _context.SaveChanges();
            
           if(ConnectedUsers.TryGetValue(user.ToString(), out string connectionId))
            {
                await Clients.Client(connectionId).SendAsync("ReceiveMessage", user, message, LoginId);
            }
            
        }
    }
}
