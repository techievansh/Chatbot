﻿using System.ComponentModel.DataAnnotations;

namespace ChatBotUsingSignalR.Models
{
    public class ChatMgt
    {
        [Key]
        public int ChatMgtId { get; set; }
        public int? ReceiverId { get; set; }
        public string? Chat { get; set; }
        public int? SenderId { get; set; }
    }
}
