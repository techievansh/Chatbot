﻿$(document).ready(function () {
    // Handle user click event
    $('.userListItems').on('click', '.user-item', function () {
        $('.message ').remove();
        const LoginId = parseInt($('#loginId').val());
        const userId = parseInt($(this).data('id'));
        const username = $(this).text();
        $('#UserName').text(username);
        $('#UserId').text(userId);
        $.ajax({
            type: "GET",
            url: "/Chat/GetUserChat",
            data: { recieverId: userId, senderId: LoginId },
            success: function (data) {
                data.forEach(item => {
                    if (item.senderId == LoginId) {
                        const newMessage = `
                                                            <div class="message sent">
                                                                <div class="bubble">${item.chat}</div>
                                                                <div class="timestamp">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                                                            </div>
                                                        `;
                        chatBody.insertAdjacentHTML('beforeend', newMessage);
                        $("#userInput").val(""); // Clear input field
                        chatBody.scrollTop = chatBody.scrollHeight; // Scroll to the bottom
                    }
                    else {
                        const newMessage = `
                                                <div class="message received">
                                                    <div class="bubble">${item.chat}</div>
                                                    <div class="timestamp">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                                                </div>
                                            `;
                        chatBody.insertAdjacentHTML('beforeend', newMessage);
                        chatBody.scrollTop = chatBody.scrollHeight; // Scroll to the bottom
                    }
                });
            }
        });
        // You can implement further actions based on the selected user
    });

    $("#userInput").keydown(function (event) {
        if (event.key === "Enter") {
            event.preventDefault(); // Prevent default action (form submission)
            sendMessage();
        }
    });

    // Send message on button click
    $("#sendButton").click(sendMessage);


    // Create a connection to the SignalR hub
    const connection = new signalR.HubConnectionBuilder()
        .withUrl("/chatHub") // Adjust the URL to your hub
        .build();

    // Start the connection
    connection.start().catch(function (err) {
        return console.error(err.toString());
    });

    // Handle the send button click
    function sendMessage() {
        const userMessage = $("#userInput").val().trim(); // Trim whitespace
        const Id = $('#UserId').text();
        const login = $('#loginId').val();
        const userId = parseInt(Id);
        const LoginId = parseInt(login);
        if (Id !== "Id" && userId && LoginId) {
            if (userMessage) {
                // Display the sent message immediately
                const newMessage = `
                        <div class="message sent">
                            <div class="bubble">${userMessage}</div>
                            <div class="timestamp">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                    `;
                chatBody.insertAdjacentHTML('beforeend', newMessage);
                $("#userInput").val(""); // Clear input field
                chatBody.scrollTop = chatBody.scrollHeight; // Scroll to the bottom

                // Call the SendMessage method on the hub
                connection.invoke("SendMessage", userId, userMessage, LoginId)
                    .catch(function (err) {
                        console.error(err.toString());
                    });
            } else {
                alert("Please enter a message.");
            }
        } else {
            alert("Please select a user.");
        }

    }

    // Listen for messages from the server
    connection.on("ReceiveMessage", function (userId, userMessage, LoginId) {
        const newMessage = `
                <div class="message received">
                    <div class="bubble">${userMessage}</div>
                    <div class="timestamp">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
            `;
        chatBody.insertAdjacentHTML('beforeend', newMessage);
        chatBody.scrollTop = chatBody.scrollHeight; // Scroll to the bottom
    });
});
function filterChats() {
    // Get the value of the search input
    const input = document.getElementById('searchInput');
    const filter = input.value.toLowerCase();
    const chatList = document.getElementById('recentChats');
    const chats = chatList.getElementsByClassName('recent-chat');

    // Loop through all chat items and hide those that don't match the search query
    for (let i = 0; i < chats.length; i++) {
        const chatButton = chats[i].getElementsByClassName('user-item')[0];
        const chatName = chatButton.textContent || chatButton.innerText;

        if (chatName.toLowerCase().indexOf(filter) > -1) {
            chats[i].style.display = ""; // Show the chat item
        } else {
            chats[i].style.display = "none"; // Hide the chat item
        }
    }
}