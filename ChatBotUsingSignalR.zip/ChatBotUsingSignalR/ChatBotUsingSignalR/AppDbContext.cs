﻿using ChatBotUsingSignalR.Models;
using Microsoft.EntityFrameworkCore;

namespace ChatBotUsingSignalR
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
        {
        }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<AspNetUsers> AspNetUsers { get; set; }
        public DbSet<ChatMgt> ChatMgt { get; set; }
    }
}
