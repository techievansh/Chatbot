﻿using ChatBotUsingSignalR.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ChatBotUsingSignalR.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context) 
        {
            _context=context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Registration(AspNetUsers aspNetUsers)
        {
            var getUserDetail=_context.AspNetUsers.Add(aspNetUsers);
            _context.SaveChanges();
            return View("Login");
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

         [HttpPost]
        public async Task<IActionResult> Login(LoginModel loginModel)
        {
            var getUserDetail = _context.AspNetUsers.Where(x => x.Email == loginModel.Email && x.Password==loginModel.Password).FirstOrDefault();
            if(getUserDetail!=null)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.NameIdentifier, getUserDetail.Id.ToString()),
                    new Claim(ClaimTypes.Name, getUserDetail.FirstName)
                };
                var claimsIdentity=new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties=new AuthenticationProperties { IsPersistent = true };
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
                return RedirectToAction("ChatMgt", "Chat", new { id = getUserDetail.Id });
            }
            else
            {
                return View();
            }
            
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            return RedirectToAction("Login"); // Redirect to home or login page
        }
    }
}
