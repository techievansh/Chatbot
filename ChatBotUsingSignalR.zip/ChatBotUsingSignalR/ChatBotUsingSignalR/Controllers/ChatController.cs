﻿using Microsoft.AspNetCore.Mvc;

namespace ChatBotUsingSignalR.Controllers
{
    public class ChatController : Controller
    {
        private readonly AppDbContext _context;

        public ChatController(AppDbContext context) 
        {
            _context=context;
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetAllUsers()
        {
            var getAllData = _context.AspNetUsers.ToList();
            return View(getAllData);
        }
        [HttpGet]
        public IActionResult ChatMgt(int id)
        {
            var getAllData = _context.AspNetUsers.Where(x=>x.Id!=id).ToList();
            ViewBag.loginId = id;
            return View(getAllData);
        }
        [HttpGet]
        public IActionResult GetUserChat(int recieverId,int senderId)
        {
            var sendermsg = _context.ChatMgt.Where(x => x.ReceiverId == recieverId && x.SenderId == senderId || x.SenderId == recieverId && x.ReceiverId == senderId).ToList();
            return Json(sendermsg);
        }
    }
}
