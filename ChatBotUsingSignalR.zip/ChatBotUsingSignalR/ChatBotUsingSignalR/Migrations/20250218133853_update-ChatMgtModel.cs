﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ChatBotUsingSignalR.Migrations
{
    /// <inheritdoc />
    public partial class updateChatMgtModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "ChatMgt",
                newName: "SenderId");

            migrationBuilder.AddColumn<int>(
                name: "ReceiverId",
                table: "ChatMgt",
                type: "int",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReceiverId",
                table: "ChatMgt");

            migrationBuilder.RenameColumn(
                name: "SenderId",
                table: "ChatMgt",
                newName: "UserId");
        }
    }
}
